<?php

class UserType {

    const WeikfieldAdmin = 0;
    const Admin = 1;
    const DM = 2;
    const RM = 3;
    const ASM = 4;
    const MDO = 5;
    const SE = 6;
    const Distributor = 7;
    const Dealer = 8;

    public static function getAll() {
        return array(
            UserType::WeikfieldAdmin => "Administrator",
            UserType::Admin => "Intouch Administrator",
            UserType::DM => "Decisional Manager",
            UserType::RM => "Regional Manager",
            UserType::ASM => "Area Sales Manager",
            UserType::MDO => "Marketing Development Officer ",
            UserType::SE => "Sales Executive",
            UserType::Distributor => "Distributor",
            UserType::Dealer => "Dealer",
        );
    }

    public static function getName($usertype) {
        $all = UserType::getAll();
        if (isset($all[$usertype])) {
            return $all[$usertype];
        } else {
            return "Not Found";
        }
    }

}

class Status {

    const STATUS_SUCCESS = 1;
    const STATUS_NOT_PROCESS = 2;
    const STATUS_MISSING_INV_NO = 4;
    const STATUS_MISSING_DATE = 8;
    const STATUS_MISSING_DEALER_NAME = 16;
    const STATUS_MISSING_ITEMS = 32;
    const STATUS_MISSING_INVOICE_QTY = 64;
    const STATUS_MISSING_INVOICE_AMOUNT = 128;
    const STATUS_REPRINT = 256;
    const STATUS_REPROCESS = 512;
    const STATUS_DEALER_NOT_RESOLVED = 1024;
    const STATUS_ITEMS_NOT_RESOLVED = 2048;
    const STATUS_MISSING_PARSER = 4096;
    const STATUS_EXTRA_INVOICE = 8192;
    const STATUS_NOT_TTK_DIST = 16384;
    const STATUS_DEALER_NOT_MAPPED = 32768;
    const STATUS_NOT_TTK_INVOICE = 65536;
    const STATUS_MULTIPLE_INVOICES = 131072;

    public static function getAll() {
        return array(
            Status::STATUS_SUCCESS => "Successfully Processed",
            Status::STATUS_NOT_PROCESS => "Not Processed",
            Status::STATUS_MISSING_INV_NO => "Missing invoice number",
            Status::STATUS_MISSING_DATE => "Missing invoice date",
            Status::STATUS_MISSING_DEALER_NAME => "Missing dealer name",
            Status::STATUS_MISSING_ITEMS => "Missing items",
            Status::STATUS_MISSING_INVOICE_QTY => "Missing invoice quantity",
            Status::STATUS_MISSING_INVOICE_AMOUNT => "Missing invoice amount",
            Status::STATUS_REPRINT => "Reprint Invoice", // reprint if 
            Status::STATUS_REPROCESS => "Reprocess Invoice",
            Status::STATUS_DEALER_NOT_RESOLVED => "Dealer not resolved",
            Status::STATUS_ITEMS_NOT_RESOLVED => "Items not resolved",
            Status::STATUS_MISSING_PARSER => "Parser file missing",
            Status::STATUS_EXTRA_INVOICE => "Duplicate Invoice",
            Status::STATUS_NOT_TTK_DIST => "Not a Weikfield Dist",
            Status::STATUS_DEALER_NOT_MAPPED => "Dealer not mapped",
            Status::STATUS_NOT_TTK_INVOICE => "Not a Weikfield Invoice",
            Status::STATUS_MULTIPLE_INVOICES => "Multiple invices in text"
                
        );
    }

    public static function getStatusMsg($statusnumber) {
        $all = Status::getAll();
        if (isset($all[$statusnumber])) {
            return $all[$statusnumber];
        } else {
            return "Not Found";
        }
    }

    public static function getCombinedStatusMsg($combinedstatusnumber) {
        //$binnumber = decbin($combinedstatusnumber);
        $errorstring = Status::bindecValues($combinedstatusnumber);
        $errorarray = explode(",", $errorstring);
        $all = Status::getAll();
        $errormsg = "";
        foreach ($errorarray as $errornum) {
            if (isset($all[$errornum])) {
                $errormsg .= $all[$errornum] . ",";
            }
        }
        $errormsg = substr($errormsg, 0, -1);
        return $errormsg;
    }

    public static function getStatusNumberArray($combinedstatusnumber) {
        $errorstring = Status::bindecValues($combinedstatusnumber);
        return $errorstring;
    }

    static function bindecValues($decimal, $reverse = false, $inverse = false) {
        /*
         * ex: bindecValues("1023");
         * returns : 1,2,4,8,16,32,64,128,256,512
          1. This function takes a decimal, converts it to binary and returns the
          decimal values of each individual binary value (a 1) in the binary string.
          You can use larger decimal values if you pass them to the function as a string!
          2. The second optional parameter reverses the output.
          3. The third optional parameter inverses the binary string, eg 101 becomes 010.
          -- darkshad3 at yahoo dot com
         */

        $bin = decbin($decimal);
        if ($inverse) {
            $bin = str_replace("0", "x", $bin);
            $bin = str_replace("1", "0", $bin);
            $bin = str_replace("x", "1", $bin);
        }
        $total = strlen($bin);

        $stock = array();

        for ($i = 0; $i < $total; $i++) {
            if ($bin{$i} != 0) {
                $bin_2 = str_pad($bin{$i}, $total - $i, 0);
                array_push($stock, bindec($bin_2));
            }
        }

        $reverse ? rsort($stock) : sort($stock);
        return implode(",", $stock);
    }

}

class Permissions {

    const PERMISSION_APPROVE = 1;

    public static function getAll() {
        return array(
            Permissions::PERMISSION_APPROVE => "Approve"
        );
    }

    public static function getName($permissiontype) {
        $all = Permissions::getAll();
        if (isset($all[$permissiontype])) {
            return $all[$permissiontype];
        } else {
            return "Not Found";
        }
    }

}

class INS_status {

    const NOT_STARTED = 1;
    const STARTED = 2;
    const COMPLETED = 3;
    const FAILED = 4;
    const HOLD = 5;

    public static function getAll() {
        return array(
            INS_status::NOT_STARTED => "Not Started",
            INS_status::STARTED => "Started",
            INS_status::COMPLETED => "Completed",
            INS_status::FAILED => "Failed",
            INS_status::HOLD => "Hold"
        );
    }

}

class Inactive {

    const ACTIVE = 0;
    const INACTIVE = 1;

    public static function getAll() {
        return array(
            Inactive::ACTIVE => "ACTIVE",
            INS_status::INACTIVE => "INACTIVE",
        );
    }

}

class distSalesReturnType {

    const DSRC = 1;
    const CSRC = 2;
    const SRC = 3;

    public static function getAll() {
        return array(
            distSalesReturnType::DSRC => "Dealer or Damage Sales Return Challan",
            distSalesReturnType::CSRC => "Customer Sales Return Challan",
            distSalesReturnType::SRC => "Sales Return Challan"
        );
    }

    public static function getRetrunMsg($returnnumber) {
        $all = distSalesReturnType::getAll();
        if (isset($all[$returnnumber])) {
            return $all[$returnnumber];
        } else {
            return "Not Found";
        }
    }

}

class SR_status {

    const STATUS_OPEN = 0;
    const STATUS_SUBMITTED = 1;
    const STATUS_APPROVED = 2;

    public static function getAll() {
        return array(
            SR_status::STATUS_OPEN => "Sales return created",
            SR_status::STATUS_SUBMITTED => "Sales return submitted for approval",
            SR_status::STATUS_APPROVED => "Sales return approved",
        );
    }

    public static function getStatusMsg($statusnumber) {
        $all = SR_status::getAll();
        if (isset($all[$statusnumber])) {
            return $all[$statusnumber];
        } else {
            return "Not Found";
        }
    }

}

class ITEM_STATUS {

    const NOT_DEFINED = 0;
    const IS_MASTER_ITEM = 1;
    const NOT_MASTER_ITEM = 2;

    public static function getAll() {
        
        return array(
            ITEM_STATUS::NOT_DEFINED => "Not Defined",
            ITEM_STATUS::IS_MASTER_ITEM => "Item belongs to Master Item",
            ITEM_STATUS::NOT_MASTER_ITEM => "Item does not belongs to Master Item"
        );
    }

    public static function getStatusMsg($statusnumber) {
        $all = ITEM_STATUS::getAll();
        if (isset($all[$statusnumber])) {
            return $all[$statusnumber];
        } else {
            return "Not Found";
        }
    }

}

class TTK_DEALER_TYPE {

    const METRO = 1;
    const UPCOUNTRY = 2;

    public static function getALL() {
        return array(
            TTK_DEALER_TYPE::METRO => "Metro",
            TTK_DEALER_TYPE::UPCOUNTRY => "Upcountry"
        );
    }

    public static function getStatusMsg($typenumber) {
        $all = TTK_DEALER_TYPE::getAll();
        if (isset($all[$typenumber])) {
            return $all[$typenumber];
        } else {
            return "Not Found";
        }
    }

}

class SLAB_TYPE {

    const QUANTITY = 1;
    const AMOUNT = 2;

    public static function getALL() {
        return array(
            SLAB_TYPE::QUANTITY => "Quantity",
            SLAB_TYPE::AMOUNT => "Amount"
        );
    }

    public static function getStatusMsg($typenumber) {
        $all = SLAB_TYPE::getAll();
        if (isset($all[$typenumber])) {
            return $all[$typenumber];
        } else {
            return "Not Found";
        }
    }

}

class ENROLLMENT_TYPE {

    const TIE_UP = 0;
    const GTO = 1;

    public static function getAll() {
        return array(
            ENROLLMENT_TYPE::TIE_UP => "Tie-Up Enrollment",
            ENROLLMENT_TYPE::GTO => "GTO Scheme Enrollment"
        );
    }

    public static function getStatusMsg($etype) {
        $all = ENROLLMENT_TYPE::getAll();
        if (isset($all[$etype])) {
            return $all[$etype];
        } else {
            return "Not Found";
        }
    }

}

class POS_TYPE {

const IT_POS = 1;
const ANDROID = 2;

public static function getAll() {
    return array(
        Instances::IT_POS => "IT-POS INSTANCES",
        Instances::ANDROID => "ANDROID INSTANCES"
    );
}

public static function getStatusMsg($etype) {
    $all = InstanceType::getAll();
    if (isset($all[$etype])) {
        return $all[$etype];
    } else {
        return "Not Found";
    }
}

}

class DataType {

    const taxes = 1;
    const region_categories = 2;
    const weikfield_items = 3;

    public static function getAll() {
        return array(
            DataType::taxes => "Taxes",
            DataType::region_categories => "Region Category",
            DataType::weikfield_items => "Weikfield Items",
        );
    }

    public static function getName($type) {
        $all = DataType::getAll();
        if (isset($all[$type])) {
            return $all[$type];
        } else {
            return "Unknown";
        }
    }

}

class ReportCategories {

    const custard_powder = 1;
    const green_tea = 2;
    const pasta = 3;
    const instant_pasta = 4;
    const sauces = 5;

    public static function getAll() {
        return array(
            ReportCategories::custard_powder => "Custard Powder",
            ReportCategories::green_tea => "Green Tea",
            ReportCategories::pasta => "Pasta",
            ReportCategories::instant_pasta => "Instant Pasta",
            ReportCategories::sauces => "Sauces",
        );
    }

    public static function getName($type) {
        $all = ReportCategories::getAll();
        if (isset($all[$type])) {
            return $all[$type];
        } else {
            return "Unknown";
        }
    }

}

?>
