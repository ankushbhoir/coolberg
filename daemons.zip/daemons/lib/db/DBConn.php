<?php
require_once "lib/db/dbobject.php";

class DBConn extends dbobject {
}

?>
