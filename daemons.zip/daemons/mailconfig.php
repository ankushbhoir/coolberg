<?php
ini_set('include_path','/home/ttk/daemons:'.ini_get('include_path'));
define("DEF_SITEURL",    "http://ttkprestige.onintouch.com/");
define("DB_SERVER",      "localhost");
define("DB_NME", "ttk");
define("DB_USR", "ttk");
define("DB_PWD", "00!YIUJRS6PDWE");
#idefine("LOGFILE_ERROR", "/home/dt/ic_html/logs/vlcc.error.log");
#define("LOGFILE_LOGIN", "/home/vlcc/public_html/logs/vlcc.login.log");
#define("DEF_ISSUE_URL","http://tracker.intouchrewards.com/signon.php");
define("DEF_ISSUE_AUTHKEY","ed6c0138a5764b8aa071eb85cad65098");
define("DEF_ISSUE_PROJECTID","12");
define("DEF_CURR_LICENSE_EXPDT","31122018");

# log msg types
define("LOG_MSGTYPE_ERROR", 1);
define("LOG_MSGTYPE_WARNING", 2);
define("LOG_MSGTYPE_DEBUG", 3);
define("LOG_MSGTYPE_REPLY", 4);
define("LOG_MSGTYPE_TRIAL", 5);
define("LOG_MSGTYPE_INFO", 6);
define("LOG_MSGTYPE_EXCEPTION", 7);

define("DEF_INTOUCH_STARTNO", 1090808);
define("DEF_SMS_PHONENO", "09220092200");
define("DEF_VCODE_OFFSET", 50000);

define("config_disable_email",false);
define("config_disable_sms",false);

if (!defined("DEF_PAGE_TITLE")) define("DEF_PAGE_TITLE", "VLCC Portal");
if (!defined("DEF_PAGE_KEYWORDS")) define("DEF_PAGE_KEYWORDS", "IntouchRewards.com, VLCC Distributors");
if (!defined("DEF_PAGE_DESCRIPTION")) define("DEF_PAGE_DESCRIPTION", "Portal for VLCC Distributors to analyze product sales");

$gConfig = array(
'checkin_repeat_hours' => 5,
);

define("DEF_DEBUG", true);

if (DEF_DEBUG) {
error_reporting(E_ALL);
ini_set('display_errors', '1');
}

$config_disable_email = "false";
$config_disable_sms = "true";
/*define("STATUS_NOT_PROCESSED", 0);
define("STATUS_SUCCESS", 1);
define("STATUS_ERROR", 2);
define("STATUS_REPRINT", 3);
define("STATUS_REPROCESS", 4);
define("STATUS_DEALER_NOT_RESOLVED", 11);
define("STATUS_ITEMS_NOT_RESOLVED", 12);
$STATUS = array (
	STATUS_NOT_PROCESSED => array("Not Processed", "Process All", "admin/invoices/processall"),
	STATUS_SUCCESS => array("Processed", "Run Again", "admin/invoices/processall/status=".STATUS_SUCCESS."/"),
	STATUS_ERROR => array("Error Processing", "Process Again", "admin/invoices/processall/status=".STATUS_ERROR."/"),
	STATUS_REPRINT => array("Reprint"),
	STATUS_REPROCESS => array("Reprocess", "Run", "admin/invoices/processall/status=".STATUS_REPROCESS."/"),
	STATUS_DEALER_NOT_RESOLVED => array("Dealer Not Resolved", "Resolve Dealers", "admin/dealers/resolve/"),
	STATUS_ITEMS_NOT_RESOLVED => array("Items Not Resolved", "Resolve Items", "admin/items/resolve/"),
);

function getStatusMsg($status) {
	global $STATUS;
	return $STATUS[$status][0];
}
*/
?>

