#!/usr/bin/php -q
<?php
include '/home/ttk/daemons/mailconfig.php';

require_once 'lib/db/DBConn.php';
require_once 'lib/core/Constants.php';
require_once "lib/mailparse/MimeMailParser.class.php";

define("DEF_MAILDIR_PROCESSED_FOLDER", '/home/ttk/Maildir/processed/');
define("DEF_MAILDIR_ATTACHMENTS_FOLDER", '/home/ttk/Maildir/attachments/');
define("DEF_MAILDIR_ATTACHMENTS_FOLDERNEW", '/home/ttk/public_html/Parsers/receivedPO/');
define("DEF_MAILDIR_ATTACHMENTS_FOLDERNEW_FOR_VIEW", '/home/ttk/public_html/Parsers/receivedPOview/');
define("DEF_MAILDIR_IGNORED_FOLDER", '/home/ttk/ignored/');

$g_valid_extensions = array('pdf', 'html');

$db = new DBConn();
processMaildir('/home/ttk/Maildir/cur/');
processMaildir('/home/ttk/Maildir/new/');
processMaildir('/home/ttk/Maildir/.spam/new/');
processMaildir('/home/ttk/Maildir/.spam/cur/');

function processMailDir($maildir_path) {
    $handle = opendir($maildir_path);
    if (!$handle) return;

    /* This is the correct way to loop over the directory. */
    while (false !== ($entry = readdir($handle))) {
        $file_path = "$maildir_path$entry";
        if (!is_file($file_path)) continue;
        processMailFile($file_path);
    }

    closedir($handle);
}

function processMailFile($file_path) {
    $Parser = new MimeMailParser();
    $Parser->setPath($file_path);
    global $db;
    $headers = $Parser->getHeaders();

    $from_email = $Parser->getHeader('from');
    preg_match('/([a-zA-Z0-9+._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/', $from_email, $emailfrm);    $from_email=$emailfrm[1];
    $to_email = $Parser->getHeader('to');
    $receipt_date = $Parser->getHeader('date');
    //$re = "/(?<=@)[^.]+(?=\.)/";
    preg_match('/[^.@]*?\.\w{2,}$|[^.@]*?\.com?\.\w{2}$/', $from_email, $output_array);
    print_r($output_array);
    $exe_doamin=$output_array[0];
   
$zone = $db->fetchObject("select * from it_domain where domain='".$exe_doamin."' ");
	// print_r($zone);
 //    exit;
    if($zone){
$attachments = $Parser->getAttachments();
    if (count($attachments) == 0) { // move file to ignored folder and return
        rename($file_path, DEF_MAILDIR_IGNORED_FOLDER . basename($file_path));
        return;
    }

    // save to db and get uniqid
    
    $from_email = $db->safe($from_email);
    $to_email = $db->safe($to_email);
    $receipt_date = $db->safe($receipt_date);
    $db_file_path = $db->safe($file_path);
    $attachment_count = count($attachments);
    $insert_id = $db->execInsert("insert into it_incoming_vlcc_emails set from_email=$from_email, to_email=$to_email, receipt_date=$receipt_date, mailfile=$db_file_path, num_attachments = $attachment_count");

    $count=0;
    $filenames = array();
    foreach ($attachments as $attachment) {
	$count++;
        $filename = $attachment->filename;
        $filenames[] = $filename;
        $filename = $insert_id."_".$count."_".str_replace(" ", "", $filename);
//        $save_file_path = DEF_MAILDIR_ATTACHMENTS_FOLDER . $filename;
 //       if ($fp = fopen($save_file_path, 'w')) {
 //           while($bytes = $attachment->read()) {
 //               fwrite($fp, $bytes);
 //           }
 //           fclose($fp);
  //      }
echo "insert into it_po_details set from_email=$from_email, po_filenames='".$filename."',datetime='".date('Y-m-d h:i:s')."'";

        $newpo_entry = $db->execInsert("insert into it_po_details set from_email=$from_email, po_filenames='".$filename."',datetime='".date('Y-m-d h:i:s')."'");	
$save_file_path = DEF_MAILDIR_ATTACHMENTS_FOLDERNEW . $filename;
        if ($fp = fopen($save_file_path, 'w')) {
            while($bytes = $attachment->read()) {
                fwrite($fp, $bytes);
            }
            fclose($fp);
        }

        $new_file_path = DEF_MAILDIR_PROCESSED_FOLDER . $insert_id . "_". basename($file_path);
        rename($file_path, $new_file_path);
    }
    $attachment_filenames = $db->safe(join("<>", $filenames));
    $db->execUpdate("update it_incoming_vlcc_emails set attachment_filenames=$attachment_filenames where id=$insert_id");
    }
    else{

        echo "from email not allowed send email";
        return;
    }
}

